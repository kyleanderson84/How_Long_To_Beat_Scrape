from .HowLongToBeat import HowLongToBeat
from .HowLongToBeatEntry import HowLongToBeatEntry
